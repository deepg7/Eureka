import React from "react";
import "../Styling/Assignments.css";

function Assignments() {
  return (
    <div className="assignments">
      <div className="assignments__header">
        <h1>Assignments</h1>
      </div>
    </div>
  );
}

export default Assignments;
